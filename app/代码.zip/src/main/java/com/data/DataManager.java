package com.data;

import android.graphics.Bitmap;

/**
 * 负责应用的数据管理
 * Created by 廖金龙 on 2015/9/9.
 */
public class DataManager {

    private static DataManager data = new DataManager();

    private DataManager() {

    }

    public static DataManager getInstance() {
        return data;
    }

    /**
     * 当前拍好的照片
     */
    public Bitmap currentBmp;

    /**
     * 人脸图片保存路径（sd_crad为根目录）
     */
    public String faceSavePath = "/AzCamera/face";


}
